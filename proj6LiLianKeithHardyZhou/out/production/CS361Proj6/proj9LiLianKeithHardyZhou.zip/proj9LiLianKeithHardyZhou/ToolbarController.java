/*
 * File: ToolbarController.java
 * Names: Kevin Ahn, Matt Jones, Jackie Hang, Kevin Zhou
 * Class: CS 361
 * Project 4
 * Date: October 2, 2018
 * ---------------------------
 * Edited By: Zena Abulhab, Paige Hanssen, Kyle Slager, Kevin Zhou
 * Project 5
 * Date: October 12, 2018
 * ---------------------------
 * Edited By: Zeb Keith-Hardy, Michael Li, Iris Lian, Kevin Zhou
 * Project 6/7/9
 * Date: October 26, 2018/ November 3, 2018/ November 20, 2018
 */

package proj9LiLianKeithHardyZhou;

import proj9LiLianKeithHardyZhou.compiler.ErrorHandler;
import proj9LiLianKeithHardyZhou.compiler.Error;
import proj9LiLianKeithHardyZhou.compiler.Scanner;
import proj9LiLianKeithHardyZhou.compiler.Token;

import java.util.Iterator;
import java.util.List;

/**
 * This class is the controller for all of the toolbar functionality.
 * Specifically, the compile, compile and run, and stop buttons
 *
 * @author  Zeb Keith-Hardy, Michael Li, Iris Lian, Kevin Zhou
 * @author  Kevin Ahn, Jackie Hang, Matt Jones, Kevin Zhou
 * @author  Zena Abulhab, Paige Hanssen, Kyle Slager Kevin Zhou
 * @version 2.0
 * @since   10-3-2018
 *
 */
public class ToolbarController {

    private boolean scanIsDone;
    private Console console;
    private CodeTabPane codeTabPane;

    /**
     * This is the constructor of ToolbarController.
     * @param console the console
     * @param codeTabPane the tab pane
     */
    public ToolbarController(Console console, CodeTabPane codeTabPane){
        this.console = console;
        this.codeTabPane = codeTabPane;
        this.scanIsDone = true;
    }

    /**
     * Handles scanning the current CodeArea, prints results to a new code Area.
     */
    public void handleScan(){
        this.scanIsDone = false;
        ErrorHandler errorHandler = new ErrorHandler();
        Scanner scanner = new Scanner(this.codeTabPane.getFileName(), errorHandler);
        Token token = scanner.scan();
        StringBuilder tokenString = new StringBuilder();
        int errorCounter = 0;
        while(token.kind != Token.Kind.EOF){
            tokenString.append(token.toString() + "\n");
            if(token.kind == Token.Kind.ERROR){
                errorCounter+=1;
            }
            token = scanner.scan();
        }
        this.console.WriteToConsole("There were: " + errorCounter + " errors in " +
                this.codeTabPane.getFileName() + "\n","Output");
        if(errorHandler.errorsFound()){
            List<Error> errorList= errorHandler.getErrorList();
            Iterator<Error> errorIterator = errorList.iterator();
            this.console.WriteToConsole("\n","Error");
            while(errorIterator.hasNext()){
                this.console.WriteToConsole(errorIterator.next().toString() + "\n","Error");
            }
        }
        this.codeTabPane.createTabWithContent(tokenString.toString());
        this.scanIsDone = true;
    }

    /**
     * Check if the task is still running.
     * @return true if this task is done, and false otherwise
     */
    public boolean scanIsDone(){
        return this.scanIsDone;
    }
}